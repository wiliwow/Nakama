#[tauri::command]
pub async fn execute_ai_with_actions(
    prompt: String,
    window: Window,
    ai_state: State<'_, Arc<Mutex<AICompanion>>>,
    app_state: State<'_, AppState>,
    #[cfg(feature = "swiftide_integration")]
    config_manager: State<'_, Arc<std::sync::Mutex<crate::config::ConfigManager>>>,
) -> Result<(), String> {
    // Get AI response
    let (enhanced_prompt, _, _, _) = build_prompt_with_context(
        prompt.clone(),
        #[cfg(feature = "swiftide_integration")]
        config_manager,
    ).await;

    let model = {
        let ai = ai_state.lock().await;
        ai.model_clone()
    };

    // Stream the response and parse for actions
    tokio::spawn(async move {
        let client = ollama_rs::Ollama::default();
        let request = ollama_rs::generation::completion::request::GenerationRequest::new(model, enhanced_prompt);

        let mut full_response = String::new();

        match client.generate_stream(request).await {
            Ok(mut stream) => {
                while let Some(chunk_res) = stream.next().await {
                    match chunk_res {
                        Ok(chunks) => {
                            for piece in chunks {
                                full_response.push_str(&piece.response);
                                let _ = window.emit("ai-stream-chunk", piece.response.clone());
                            }
                        }
                        Err(e) => {
                            let _ = window.emit("ai-stream-error", e.to_string());
                            return;
                        }
                    }
                }

                // After response completes, parse and execute actions
                let actions = parse_ai_actions(&full_response).await;
                for action in actions {
                    match execute_ai_action(action.clone(), app_state.clone()).await {
                        Ok(result) => {
                            let _ = window.emit("ai-action-executed", result);
                        }
                        Err(err) => {
                            let _ = window.emit("ai-action-error", err);
                        }
                    }
                }

                let _ = window.emit("ai-stream-done", ());
            }
            Err(e) => {
                let _ = window.emit("ai-stream-error", e.to_string());
            }
        }
    });

    Ok(())
}